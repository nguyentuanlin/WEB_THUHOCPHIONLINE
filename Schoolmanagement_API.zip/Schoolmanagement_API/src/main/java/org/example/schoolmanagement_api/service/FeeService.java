package org.example.schoolmanagement_api.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.schoolmanagement_api.entity.Fee;
import org.example.schoolmanagement_api.entity.FeeRate;
import org.example.schoolmanagement_api.repository.FeeRateRepository;
import org.example.schoolmanagement_api.repository.FeeRepository;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
@Slf4j
@Service
@RequiredArgsConstructor
public class FeeService {

    private final FeeRepository feeRepository;
    private final FeeRateRepository feeRateRepository;

    public Fee createFee(Fee fee) {
        fee.setCreatedAt(LocalDateTime.now()); // Thiết lập thời gian tạo là thời gian hiện tại
        return feeRepository.save(fee);
    }

    public List<Fee> getAllFees() {
        return feeRepository.findAll();
    }

    public Fee getFeeById(int feeId) {
        return feeRepository.findById(feeId)
                .orElseThrow(() -> new RuntimeException("Fee not found"));
    }

    public Fee updateFee(int feeId, Fee feeDetails) {
        Fee fee = getFeeById(feeId);
        fee.setFeeName(feeDetails.getFeeName());
        fee.setDescription(feeDetails.getDescription());
        fee.setCreatedAt(LocalDateTime.now());
        return feeRepository.save(fee);
    }

    public void deleteFee(int feeId) {
        feeRepository.deleteById(feeId);
    }
    public FeeRate getCurrentFeeRate(int feeId, int periodId, LocalDate currentDate) {
        return feeRateRepository.findAllByFeeFeeIdAndFeePeriodPeriodId(feeId,periodId)
                .stream()
                .filter(feeRate -> !feeRate.getEffectiveDate().toLocalDate().isAfter(currentDate))
                .max(Comparator.comparing(FeeRate::getEffectiveDate)) // lấy ngày gần nhất
                .orElseThrow(() -> new RuntimeException("No applicable FeeRate found"));
    }
}