package org.example.schoolmanagement_api.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.sql.Timestamp;

@Entity
@Table(name = "authenticationlogs")
@Data
public class AuthenticationLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LogID")
    private Integer logId;

    @Column(name = "UserID")
    private Integer userId;

    @Column(name = "LoginTime", nullable = false)
    private Timestamp loginTime;
}
