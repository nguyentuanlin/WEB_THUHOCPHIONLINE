package org.example.schoolmanagement_api.service;

import lombok.RequiredArgsConstructor;
import org.example.schoolmanagement_api.entity.FeePeriod;
import org.example.schoolmanagement_api.repository.FeePeriodRepository;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
public class FeePeriodService {

    private final FeePeriodRepository feePeriodRepository;

    public FeePeriod createFeePeriod(FeePeriod feePeriod) {
        feePeriod.setCreatedAt(Timestamp.from(Instant.now()));
        return feePeriodRepository.save(feePeriod);
    }

    public List<FeePeriod> getAllFeePeriods() {
        return feePeriodRepository.findAll();
    }

    public FeePeriod getFeePeriodById(int periodId) {
        return feePeriodRepository.findById(periodId)
                .orElseThrow(() -> new RuntimeException("Fee period not found"));
    }

    public FeePeriod updateFeePeriod(int periodId, FeePeriod feePeriodDetails) {
        FeePeriod feePeriod = getFeePeriodById(periodId);
        feePeriod.setPeriodName(feePeriodDetails.getPeriodName());
        feePeriod.setStartDate(feePeriodDetails.getStartDate());
        feePeriod.setEndDate(feePeriodDetails.getEndDate());
        return feePeriodRepository.save(feePeriod);
    }

    public void deleteFeePeriod(int periodId) {
        feePeriodRepository.deleteById(periodId);
    }
}
