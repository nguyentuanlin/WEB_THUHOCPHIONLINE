package org.example.schoolmanagement_api.dto.response;

import lombok.Data;

import java.time.LocalDate;

@Data
public class StudentDTO {
    private Integer studentId;
    private String studentName;
    private LocalDate dateOfBirth;
    private Integer parentId;
    private String studentClass;
}
