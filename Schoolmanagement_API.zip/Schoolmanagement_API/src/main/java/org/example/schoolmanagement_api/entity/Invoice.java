package org.example.schoolmanagement_api.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.sql.Date;

@Entity
@Table(name = "invoices")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Invoice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "InvoiceID")
    private Integer invoiceId;

    @ManyToOne
    @JoinColumn(name = "StudentID", nullable = false)
    private Student student;

    @Column(name = "Amount", nullable = false)
    private BigDecimal amount;

    @Column(name = "IssuedDate", nullable = false)
    private Date issuedDate;

    @Column(name = "Status", nullable = false)
    @Enumerated(EnumType.STRING)
    private InvoiceStatus status = InvoiceStatus.UNPAID;

    @Column(name = "PaidDate")
    private Date paidDate; // Thêm trường để lưu ngày thanh toán

    public enum InvoiceStatus {
        PAID, UNPAID
    }
}
