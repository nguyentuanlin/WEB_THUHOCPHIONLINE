package org.example.schoolmanagement_api.service;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.example.schoolmanagement_api.dto.request.StudentCreateRequest;
import org.example.schoolmanagement_api.dto.response.StudentDTO;
import org.example.schoolmanagement_api.entity.FeeRate;
import org.example.schoolmanagement_api.entity.Invoice;
import org.example.schoolmanagement_api.entity.Student;
import org.example.schoolmanagement_api.entity.User;
import org.example.schoolmanagement_api.exception.AppException;
import org.example.schoolmanagement_api.exception.ErrorCode;
import org.example.schoolmanagement_api.mapper.StudentMapper;
import org.example.schoolmanagement_api.repository.FeeRateRepository;
import org.example.schoolmanagement_api.repository.InvoiceRepository;
import org.example.schoolmanagement_api.repository.StudentRepository;
import org.example.schoolmanagement_api.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StudentService {

    private final StudentRepository studentRepository;
    private final FeeRateRepository feeRateRepository;
    private final UserRepository userRepository;
    private final StudentMapper studentMapper;
    private final InvoiceRepository invoiceRepository;

    @Transactional
    public Student createStudent(StudentCreateRequest request) {
        // Tạo mới sinh viên từ yêu cầu
        Student student = Student.builder()
                .studentName(request.getStudentName())
                .dateOfBirth(request.getDateOfBirth())
                .studentClass(request.getStudentClass())
                .createdAt(LocalDateTime.now())
                .build();

        // Gán phụ huynh nếu có trong yêu cầu
        if (request.getParentId() != null) {
            User parent = userRepository.findById(request.getParentId())
                    .orElseThrow(() -> new AppException(ErrorCode.USER_NOT_FOUND));
            student.setParent(parent);
        }

        // Gán và kiểm tra danh sách phí học (FeeRate) nếu có trong yêu cầu
        List<FeeRate> feeRates = new ArrayList<>();
        if (request.getFeeRateIds() != null && !request.getFeeRateIds().isEmpty()) {
            feeRates = feeRateRepository.findAllById(request.getFeeRateIds());

            // Kiểm tra xem tất cả FeeRate IDs có tồn tại không
            if (feeRates.size() != request.getFeeRateIds().size()) {
                throw new AppException(ErrorCode.FEE_RATE_NOT_FOUND);
            }

            student.setFeeRates(feeRates);
        }

        // Lưu sinh viên vào cơ sở dữ liệu
        student = studentRepository.save(student);

        // Tạo Invoice cho sinh viên với tổng số tiền từ các FeeRate
        createInvoiceForStudent(student, feeRates);

        return student;
    }

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public StudentDTO getStudentById(int studentId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new AppException(ErrorCode.STUDENT_NOT_FOUND));
        return studentMapper.toStudentDTO(student);
    }

    @Transactional
    public StudentDTO updateStudent(int studentId, StudentCreateRequest request) {
        Student existingStudent = studentRepository.findById(studentId)
                .orElseThrow(() -> new AppException(ErrorCode.STUDENT_NOT_FOUND));

        existingStudent.setStudentName(request.getStudentName());
        existingStudent.setDateOfBirth(request.getDateOfBirth());
        existingStudent.setStudentClass(request.getStudentClass());
        existingStudent.setLastUpdatedAt(LocalDateTime.now());

        // Gán lại phụ huynh nếu có
        if (request.getParentId() != null) {
            User parent = userRepository.findById(request.getParentId())
                    .orElseThrow(() -> new AppException(ErrorCode.USER_NOT_FOUND));
            existingStudent.setParent(parent);
        }

        // Gán lại danh sách phí học (FeeRate) nếu có
        if (request.getFeeRateIds() != null && !request.getFeeRateIds().isEmpty()) {
            List<FeeRate> feeRates = feeRateRepository.findAllById(request.getFeeRateIds());
            existingStudent.setFeeRates(feeRates);

            // Cập nhật Invoice cho sinh viên với danh sách FeeRate mới
            createInvoiceForStudent(existingStudent, feeRates);
        }

        Student updatedStudent = studentRepository.save(existingStudent);
        return studentMapper.toStudentDTO(updatedStudent);
    }

    @Transactional
    public void deleteStudent(int studentId) {
        if (!studentRepository.existsById(studentId)) {
            throw new AppException(ErrorCode.STUDENT_NOT_FOUND);
        }
        studentRepository.deleteById(studentId);
    }

    @Transactional
    public List<Student> saveStudentsFromExcel(MultipartFile file) throws IOException {
        List<Student> students = new ArrayList<>();
        try (InputStream inputStream = file.getInputStream();
             Workbook workbook = WorkbookFactory.create(inputStream)) {

            Sheet sheet = workbook.getSheetAt(0);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                // Tạo đối tượng Student từ file Excel
                Student student = Student.builder()
                        .studentName(getCellStringValue(row.getCell(0)))
                        .dateOfBirth(getCellDateValue(row.getCell(1), formatter))
                        .studentClass(getCellStringValue(row.getCell(2)))
                        .createdAt(LocalDateTime.now())
                        .build();

                // Gán Parent nếu có
                Integer parentId = getCellIntegerValue(row.getCell(3));
                if (parentId != null) {
                    User parent = userRepository.findById(parentId)
                            .orElseThrow(() -> new AppException(ErrorCode.USER_NOT_FOUND));
                    student.setParent(parent);
                }

                // Gán danh sách phí học (FeeRate) nếu có
                List<Integer> feeRateIds = getFeeRateIds(row.getCell(4));
                List<FeeRate> feeRates = new ArrayList<>();
                if (feeRateIds != null && !feeRateIds.isEmpty()) {
                    feeRates = feeRateRepository.findAllById(feeRateIds);
                    student.setFeeRates(feeRates);
                }

                // Lưu sinh viên vào cơ sở dữ liệu
                student = studentRepository.save(student);

                // Tạo Invoice cho sinh viên
                createInvoiceForStudent(student, feeRates);

                students.add(student);
            }
            return students;
        }
    }

    // Phương thức tạo Invoice cho Student
    private void createInvoiceForStudent(Student student, List<FeeRate> feeRates) {
        BigDecimal totalAmount = feeRates.stream()
                .map(feeRate -> BigDecimal.valueOf(feeRate.getAmount()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        Invoice invoice = Invoice.builder()
                .student(student)
                .amount(totalAmount)
                .issuedDate(Date.valueOf(LocalDate.now()))
                .status(Invoice.InvoiceStatus.UNPAID)
                .build();

        invoiceRepository.save(invoice);
    }

    // Các phương thức hỗ trợ đọc dữ liệu từ Excel
    private String getCellStringValue(Cell cell) {
        return cell != null ? cell.getStringCellValue().trim() : null;
    }

    private Integer getCellIntegerValue(Cell cell) {
        return cell != null ? (int) cell.getNumericCellValue() : null;
    }

    private LocalDate getCellDateValue(Cell cell, DateTimeFormatter formatter) {
        if (cell != null && cell.getCellType() == CellType.STRING) {
            return LocalDate.parse(cell.getStringCellValue(), formatter);
        } else if (cell != null && cell.getCellType() == CellType.NUMERIC) {
            return cell.getLocalDateTimeCellValue().toLocalDate();
        }
        return null;
    }

    private List<Integer> getFeeRateIds(Cell cell) {
        if (cell != null && cell.getCellType() == CellType.STRING) {
            String[] ids = cell.getStringCellValue().split(",");
            List<Integer> feeRateIds = new ArrayList<>();
            for (String id : ids) {
                feeRateIds.add(Integer.parseInt(id.trim()));
            }
            return feeRateIds;
        }
        return null;
    }
}
