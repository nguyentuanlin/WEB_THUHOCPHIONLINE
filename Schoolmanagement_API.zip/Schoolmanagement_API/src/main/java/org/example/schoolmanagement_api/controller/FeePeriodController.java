package org.example.schoolmanagement_api.controller;

import lombok.RequiredArgsConstructor;

import org.example.schoolmanagement_api.dto.response.ApiResponse;
import org.example.schoolmanagement_api.entity.FeePeriod;
import org.example.schoolmanagement_api.service.FeePeriodService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/feeperiods")
@RequiredArgsConstructor
public class FeePeriodController {

    private final FeePeriodService feePeriodService;
    
    @PostMapping
    public ApiResponse<FeePeriod> createFeePeriod(@RequestBody FeePeriod feePeriod) {
        return ApiResponse.<FeePeriod>builder()
            .code(100)
            .message("FeePeriod created successfully")
            .result(feePeriodService.createFeePeriod(feePeriod))
            .build();
    }

    @GetMapping
    public ApiResponse<List<FeePeriod>> getAllFeePeriods() {
        return ApiResponse.<List<FeePeriod>>builder()
            .code(200)
            .message("FeePeriods retrieved successfully")
            .result(feePeriodService.getAllFeePeriods())
            .build();
    }

    @GetMapping("/{periodId}")
    public ApiResponse<FeePeriod> getFeePeriodById(@PathVariable int periodId) {
        FeePeriod feePeriod = feePeriodService.getFeePeriodById(periodId);
        return ApiResponse.<FeePeriod>builder()
            .code(200)
            .message("FeePeriod retrieved successfully")
            .result(feePeriod)
            .build();
    }

    @PutMapping("/{periodId}")
    public ApiResponse<FeePeriod> updateFeePeriod(@PathVariable int periodId, @RequestBody FeePeriod feePeriod) {
        FeePeriod updatedFeePeriod = feePeriodService.updateFeePeriod(periodId, feePeriod);
        return ApiResponse.<FeePeriod>builder()
            .code(200)
            .message("FeePeriod updated successfully")
            .result(updatedFeePeriod)
            .build();
    }

    @DeleteMapping("/{periodId}")
    public ApiResponse<Void> deleteFeePeriod(@PathVariable int periodId) {
        feePeriodService.deleteFeePeriod(periodId);
        return ApiResponse.<Void>builder()
            .code(200)
            .message("FeePeriod deleted successfully")
            .build();
    }
    
}
