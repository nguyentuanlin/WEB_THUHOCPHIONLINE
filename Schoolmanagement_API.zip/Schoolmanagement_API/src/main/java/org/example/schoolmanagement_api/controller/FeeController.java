package org.example.schoolmanagement_api.controller;

import lombok.RequiredArgsConstructor;
import org.example.schoolmanagement_api.dto.response.ApiResponse;
import org.example.schoolmanagement_api.dto.response.FeeRateDTO;
import org.example.schoolmanagement_api.entity.Fee;
import org.example.schoolmanagement_api.entity.FeePeriod;
import org.example.schoolmanagement_api.entity.FeeRate;
import org.example.schoolmanagement_api.mapper.FeeRateMapper;
import org.example.schoolmanagement_api.service.FeeService;
import org.example.schoolmanagement_api.service.FeePeriodService;
import org.example.schoolmanagement_api.service.FeeRateService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/fees")
@RequiredArgsConstructor
public class FeeController {

    private final FeeService feeService;
    private final FeeRateService feeRateService;
    private final FeePeriodService feePeriodService;
    private final FeeRateMapper feeRateMapper;

    // API tạo mới Fee
    @PostMapping
    public ApiResponse<Fee> createFee(@RequestBody Fee fee) {
        Fee createdFee = feeService.createFee(fee);
        return ApiResponse.<Fee>builder()
                .code(1000)
                .message("Fee created successfully")
                .result(createdFee)
                .build();
    }

    // API lấy danh sách tất cả các Fee
    @GetMapping
    public ApiResponse<List<Fee>> getAllFees() {
        List<Fee> fees = feeService.getAllFees();
        return ApiResponse.<List<Fee>>builder()
                .code(1000)
                .message("List of fees retrieved successfully")
                .result(fees)
                .build();
    }

    // API lấy chi tiết Fee theo ID
    @GetMapping("/{feeId}")
    public ApiResponse<Fee> getFeeById(@PathVariable int feeId) {
        Fee fee = feeService.getFeeById(feeId);
        return ApiResponse.<Fee>builder()
                .code(1000)
                .message("Fee details retrieved successfully")
                .result(fee)
                .build();
    }

    // API cập nhật Fee theo ID
    @PutMapping("/{feeId}")
    public ApiResponse<Fee> updateFee(@PathVariable int feeId, @RequestBody Fee fee) {
        Fee updatedFee = feeService.updateFee(feeId, fee);
        return ApiResponse.<Fee>builder()
                .code(1000)
                .message("Fee updated successfully")
                .result(updatedFee)
                .build();
    }

    // API xóa Fee theo ID
    @DeleteMapping("/{feeId}")
    public ApiResponse<String> deleteFee(@PathVariable int feeId) {
        feeService.deleteFee(feeId);
        return ApiResponse.<String>builder()
                .code(1000)
                .message("Fee deleted successfully")
                .result("Fee with ID " + feeId + " has been deleted")
                .build();
    }

    @GetMapping("/{feeId}/rates")
    public ApiResponse<List<FeeRateDTO>> getFeeRates(@PathVariable int feeId) {
        // Lấy danh sách FeeRate theo FeeID và chuyển đổi sang DTO
        List<FeeRateDTO> feeRates = feeRateService.getAllRatesForFee(feeId).stream()
                .map(feeRateMapper::toDTO) // Chuyển đổi FeeRate entity sang FeeRateDTO
                .collect(Collectors.toList());
        return ApiResponse.<List<FeeRateDTO>>builder()
                .code(1000)
                .message("List of fee rates retrieved successfully")
                .result(feeRates)
                .build();
    }
}