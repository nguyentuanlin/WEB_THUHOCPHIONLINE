package org.example.schoolmanagement_api.service;

import lombok.RequiredArgsConstructor;
import org.example.schoolmanagement_api.entity.Guide;
import org.example.schoolmanagement_api.repository.GuideRepository;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
@Service
@RequiredArgsConstructor
public class GuideService {

    private final GuideRepository guideRepository;

    public Guide createGuide(Guide guide) {
        guide.setCreatedAt(Timestamp.from(Instant.now()));
        return guideRepository.save(guide);
    }

    public List<Guide> getAllGuides() {
        return guideRepository.findAll();
    }

    public Guide getGuideById(int guideId) {
        return guideRepository.findById(guideId)
                .orElseThrow(() -> new RuntimeException("Guide not found"));
    }

    public Guide updateGuide(int guideId, Guide guideDetails) {
        Guide guide = getGuideById(guideId);
        guide.setTitle(guideDetails.getTitle());
        guide.setContent(guideDetails.getContent());
        return guideRepository.save(guide);
    }

    public void deleteGuide(int guideId) {
        guideRepository.deleteById(guideId);
    }
}
