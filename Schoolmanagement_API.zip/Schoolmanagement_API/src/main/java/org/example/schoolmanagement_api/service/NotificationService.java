package org.example.schoolmanagement_api.service;

import lombok.RequiredArgsConstructor;
import org.example.schoolmanagement_api.entity.Notification;
import org.example.schoolmanagement_api.repository.NotificationRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository notificationRepository;

    public Notification createNotification(Notification notification) {
        notification.setCreatedAt(LocalDateTime.now()); // Thiết lập thời gian tạo là thời gian hiện tại
        return notificationRepository.save(notification);
    }

    public List<Notification> getAllNotifications() {
        return notificationRepository.findAll();
    }

    public Notification getNotificationById(int notificationId) {
        return notificationRepository.findById(notificationId)
                .orElseThrow(() -> new RuntimeException("Notification not found"));
    }

    public Notification updateNotification(int notificationId, Notification notificationDetails) {
        Notification notification = getNotificationById(notificationId);
        notification.setTitle(notificationDetails.getTitle());
        notification.setMessage(notificationDetails.getMessage());
        notification.setTargetRole(notificationDetails.getTargetRole());
        return notificationRepository.save(notification);
    }

    public void deleteNotification(int notificationId) {
        notificationRepository.deleteById(notificationId);
    }

    public List<Notification> getNotificationsByRole(String role) {
        if ("Admin".equalsIgnoreCase(role)) {
            // Admin thấy tất cả thông báo
            return notificationRepository.findAll();
        } else if ("Accountant".equalsIgnoreCase(role)) {
            // Accountant thấy thông báo của chính họ và của Student
            return notificationRepository.findByTargetRoleIn(List.of("Accountant", "Student"));
        } else if ("Student".equalsIgnoreCase(role)) {
            // Student chỉ thấy thông báo dành cho họ
            return notificationRepository.findByTargetRole("Student");
        } else {
            throw new IllegalArgumentException("Invalid role");
        }
    }
}
