package org.example.schoolmanagement_api.repository;

import org.example.schoolmanagement_api.entity.FeeRate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FeeRateRepository extends JpaRepository<FeeRate, Integer> {
    List<FeeRate> findAllByFeeFeeId(int feeId);

    // Tìm tất cả các FeeRate theo FeeID và PeriodID cụ thể
    List<FeeRate> findAllByFeeFeeIdAndFeePeriodPeriodId(int feeId, int periodId);
}
