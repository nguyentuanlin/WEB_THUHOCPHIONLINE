package org.example.schoolmanagement_api.exception;

import lombok.Data;

public enum ErrorCode {
    USER_EXISTED(1001, "USER_EXISTED"),
    USER_NOT_EXISTED(1002, "USER_NOT_EXISTED"),
    AUTHENTICATION_FAILED(1003, "AUTHENTICATION_FAILED"),
    USER_NOT_FOUND(1004, "USER_NOT_FOUND"),
    INVALID_OTP(1005, "INVALID_OTP"),
    OTP_EXPIRED(1006, "OTP_EXPIRED"),
    INVALID_OLD_PASSWORD(1007, "INVALID_OLD_PASSWORD"),
    STUDENT_NOT_FOUND(1008, "STUDENT_NOT_FOUND"),
    FEE_NOT_FOUND(1009, "FEE_NOT_FOUND"),
    FEE_PERIOD_NOT_FOUND(1010, "FEE_PERIOD_NOT_FOUND"),
    FEE_RATE_NOT_FOUND(1011, "FEE_RATE_NOT_FOUND"),
    INVOICE_NOT_FOUND(1012, "INVOICE_NOT_FOUND"),
    INVALID_DATA(1013, "INVALID_DATA"),
    INVALID_DATA_STUDENTID(1014, "INVALID_DATA_STUDENTID"),
    INVALID_DATA_AMOUNT(1015, "INVALID_DATA_AMOUNT"),
    ;
        private int code;
        private String message;

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    ErrorCode(int code, String message) {
        this.code = code;
        this.message = message;
    }
}
