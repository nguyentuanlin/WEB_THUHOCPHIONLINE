package org.example.schoolmanagement_api.service;

import jakarta.transaction.Transactional;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.example.schoolmanagement_api.entity.Otp;
import org.example.schoolmanagement_api.entity.User;
import org.example.schoolmanagement_api.exception.AppException;
import org.example.schoolmanagement_api.exception.ErrorCode;
import org.example.schoolmanagement_api.repository.OtpRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Random;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class OtpService {

    OtpRepository otpRepository;
    EmailService emailService;

    public String sendOtpToUser(User user) {
        // Tạo mã OTP gồm 6 số ngẫu nhiên
        String otpCode = String.format("%06d", new Random().nextInt(1000000));
        LocalDateTime creationTime = LocalDateTime.now();
        LocalDateTime expirationTime = creationTime.plusMinutes(1); // OTP có hiệu lực trong 1 phút

        // Lưu OTP vào bảng otp
        Otp otp = Otp.builder()
                .otpCode(otpCode)
                .creationTime(creationTime)
                .expirationTime(expirationTime)
                .isUsed(false)
                .user(user)
                .build();
        otpRepository.save(otp);

        // Gửi OTP qua email
        String emailContent = "Your OTP for password reset is: " + otpCode;
        emailService.sendEmail(user.getEmail(), "Password Reset OTP", emailContent);

        return "OTP sent to your email.";
    }
    @Transactional
    public String verifyOtp(User user, String otpCode) {
        // Tìm OTP chưa được sử dụng và thuộc về người dùng
        Otp otp = otpRepository.findByOtpCodeAndUserAndIsUsedFalse(otpCode, user)
                .orElseThrow(() -> new AppException(ErrorCode.INVALID_OTP));

        // Kiểm tra nếu OTP đã hết hạn
        if (otp.getExpirationTime().isBefore(LocalDateTime.now())) {
            throw new AppException(ErrorCode.OTP_EXPIRED);
        }

        // Đánh dấu OTP là đã sử dụng
        otp.setUsed(true);
//
//        otpRepository.save(otp);

        // Xóa OTP sau khi xác thực thành công
        otpRepository.delete(otp);
        return "OTP verified successfully.";
    }
}
