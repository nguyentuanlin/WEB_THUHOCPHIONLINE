package org.example.schoolmanagement_api.service;

import jakarta.transaction.Transactional;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.example.schoolmanagement_api.dto.request.UserCreateRequest;
import org.example.schoolmanagement_api.entity.Otp;
import org.example.schoolmanagement_api.entity.User;
import org.example.schoolmanagement_api.exception.AppException;
import org.example.schoolmanagement_api.exception.ErrorCode;
import org.example.schoolmanagement_api.mapper.UserMapper;
import org.example.schoolmanagement_api.repository.OtpRepository;
import org.example.schoolmanagement_api.repository.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)

public class UserService {

    UserRepository userRepository;
    UserMapper userMapper;
    EmailService emailService;
    PasswordEncoder passwordEncoder = new BCryptPasswordEncoder(10);
    OtpRepository otpRepository;

    public User createUser(UserCreateRequest request) {
        if(userRepository.existsByUsername(request.getUsername())) {
//            throw new RuntimeException("Username already exists");
            throw new AppException(ErrorCode.USER_EXISTED);
        }
//        user.setUsername(request.getUsername());
//        user.setPassword(request.getPassword());
//        user.setRole(request.getRole());
//        user.setFullName(request.getFullName());
//        user.setEmail(request.getEmail());
//        user.setPhoneNumber(request.getPhoneNumber());

        // Thiết lập các giá trị thời gian
        Timestamp currentTimestamp = Timestamp.from(Instant.now());


        User user = User.builder()
                .username(request.getUsername())
                .password(request.getPassword())
                .role(request.getRole())
                .fullName(request.getFullName())
                .email(request.getEmail())
                .phoneNumber(request.getPhoneNumber())
//                .createdAt(currentTimestamp)
//                .lastPasswordChange(currentTimestamp)
                .build();
            user.setCreatedAt(currentTimestamp);
            user.setLastPasswordChange(currentTimestamp);

            PasswordEncoder passwordEncoder = new BCryptPasswordEncoder(10);
            user.setPassword(passwordEncoder.encode(request.getPassword()));

        // Lưu User vào cơ sở dữ liệu
        System.out.println(user);
        return userRepository.save(user);
    }
    // Method to delete a user
//    @Transactional
    public void deleteUser(int userId) {
        if (!userRepository.existsById(userId)) {
            throw new AppException(ErrorCode.USER_NOT_FOUND);
        }
        userRepository.deleteById(userId);
    }

    // Method to update a user
//    @Transactional
    public User updateUser(int userId, UserCreateRequest request) {
        User existingUser = userRepository.findById(userId)
                .orElseThrow(() -> new AppException(ErrorCode.USER_NOT_FOUND));

        // Update fields as per request
        existingUser.setUsername(request.getUsername());
        existingUser.setFullName(request.getFullName());
        existingUser.setEmail(request.getEmail());
        existingUser.setPhoneNumber(request.getPhoneNumber());
        existingUser.setRole(request.getRole());

        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder(10);
        existingUser.setPassword(passwordEncoder.encode(request.getPassword()));
        existingUser.setLastPasswordChange(Timestamp.from(Instant.now()));

        return
                userRepository.save(existingUser);
    }
    public User findUserByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new AppException(ErrorCode.USER_NOT_FOUND));
    }
//    // Gửi OTP qua email để đặt lại mật khẩu
//    public String sendOtpForResetPassword(String username) {
//        User user = userRepository.findByUsername(username)
//                .orElseThrow(() -> new AppException(ErrorCode.USER_NOT_FOUND));
//
//        // Tạo OTP
//        String otp = UUID.randomUUID().toString().substring(0, 6); // Lấy 6 ký tự đầu tiên
//
//        // Gửi OTP qua email
//        String emailContent = "Your OTP for password reset is: " + otp;
//        emailService.sendEmail(user.getEmail(), "Password Reset OTP", emailContent);
//
//        return "OTP sent to your email.";
//    }
// Thay đổi mật khẩu bằng mật khẩu cũ
public String changePasswordWithOldPassword(String username, String oldPassword, String newPassword) {
    User user = findUserByUsername(username);

    // Kiểm tra mật khẩu cũ
    if (!passwordEncoder.matches(oldPassword, user.getPassword())) {
        throw new AppException(ErrorCode.INVALID_OLD_PASSWORD);
    }

    // Đặt mật khẩu mới
    user.setPassword(passwordEncoder.encode(newPassword));
    userRepository.save(user);

    return "Password changed successfully.";
}

    // Thay đổi mật khẩu bằng OTP
    public String changePasswordWithOtp(String username, String otpCode, String newPassword) {
        User user = findUserByUsername(username);

        // Tìm và xác thực OTP
        Otp otp = otpRepository.findByOtpCodeAndUserAndIsUsedFalse(otpCode, user)
                .orElseThrow(() -> new AppException(ErrorCode.INVALID_OTP));

        if (otp.getExpirationTime().isBefore(LocalDateTime.now())) {
            throw new AppException(ErrorCode.OTP_EXPIRED);
        }

        // Xóa OTP sau khi sử dụng
        otpRepository.delete(otp);

        // Đặt mật khẩu mới
        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);

        return "Password changed successfully.";
    }

}
