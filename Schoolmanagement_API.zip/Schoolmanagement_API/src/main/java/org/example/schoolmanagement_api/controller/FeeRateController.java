package org.example.schoolmanagement_api.controller;

import lombok.RequiredArgsConstructor;
import org.example.schoolmanagement_api.dto.request.CreateFeeRateRequest;
import org.example.schoolmanagement_api.dto.response.ApiResponse;
import org.example.schoolmanagement_api.dto.response.FeeRateDTO;
import org.example.schoolmanagement_api.mapper.FeeRateMapper;
import org.example.schoolmanagement_api.service.FeeRateService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/feerates")
@RequiredArgsConstructor
public class FeeRateController {

    private final FeeRateService feeRateService;
    private final FeeRateMapper feeRateMapper;

    @PostMapping
    public ApiResponse<FeeRateDTO> createFeeRate(@RequestBody CreateFeeRateRequest request) {
        var createdFeeRate = feeRateService.createFeeRate(request);
        return ApiResponse.<FeeRateDTO>builder()
                .code(1000)
                .message("FeeRate created successfully")
                .result(feeRateMapper.toDTO(createdFeeRate))
                .build();
    }

    @GetMapping
    public ApiResponse<List<FeeRateDTO>> getAllFeeRates() {
        var feeRates = feeRateService.getAllFeeRates().stream()
                .map(feeRateMapper::toDTO)
                .collect(Collectors.toList());
        return ApiResponse.<List<FeeRateDTO>>builder()
                .code(1000)
                .message("List of FeeRates retrieved successfully")
                .result(feeRates)
                .build();
    }

    @GetMapping("/{rateId}")
    public ApiResponse<FeeRateDTO> getFeeRateById(@PathVariable int rateId) {
        var feeRate = feeRateMapper.toDTO(feeRateService.getFeeRateById(rateId));
        return ApiResponse.<FeeRateDTO>builder()
                .code(1000)
                .message("FeeRate details retrieved successfully")
                .result(feeRate)
                .build();
    }

    @PutMapping("/{rateId}")
    public ApiResponse<FeeRateDTO> updateFeeRate(@PathVariable int rateId, @RequestBody CreateFeeRateRequest request) {
        var updatedFeeRate = feeRateService.updateFeeRate(rateId, request);
        return ApiResponse.<FeeRateDTO>builder()
                .code(1000)
                .message("FeeRate updated successfully")
                .result(feeRateMapper.toDTO(updatedFeeRate))
                .build();
    }

    @DeleteMapping("/{rateId}")
    public ApiResponse<String> deleteFeeRate(@PathVariable int rateId) {
        feeRateService.deleteFeeRate(rateId);
        return ApiResponse.<String>builder()
                .code(1000)
                .message("FeeRate deleted successfully")
                .result("FeeRate with ID " + rateId + " has been deleted")
                .build();
    }
}
