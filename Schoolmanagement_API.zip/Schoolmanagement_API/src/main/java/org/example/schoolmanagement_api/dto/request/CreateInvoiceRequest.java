package org.example.schoolmanagement_api.dto.request;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.math.BigDecimal;
import java.sql.Date;

@Data
public class CreateInvoiceRequest {

    @NotNull(message = "Student ID is required")
    private Integer studentId;

    @NotNull(message = "Fee ID is required")
    private Integer feeId;

    @NotNull(message = "Period ID is required")
    private Integer periodId;

    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.01", message = "Amount must be greater than zero")
    private BigDecimal amount;

    @NotNull(message = "Issued Date is required")
    private Date issuedDate;
}
