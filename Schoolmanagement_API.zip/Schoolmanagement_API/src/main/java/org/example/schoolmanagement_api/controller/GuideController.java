package org.example.schoolmanagement_api.controller;

import lombok.RequiredArgsConstructor;
import org.example.schoolmanagement_api.dto.response.ApiResponse;
import org.example.schoolmanagement_api.entity.Guide;
import org.example.schoolmanagement_api.service.GuideService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/guides")
@RequiredArgsConstructor
public class GuideController {

    private final GuideService guideService;

    @PostMapping("")
    public ApiResponse<Guide> createGuide(@RequestBody Guide guide) {
        return ApiResponse.<Guide>builder()
                .code(1000)
                .message("Guide created successfully")
                .result(guideService.createGuide(guide))
                .build();
    }

    @GetMapping("")
    public ApiResponse<List<Guide>> getAllGuides() {
        return ApiResponse.<List<Guide>>builder()
                .code(1000)
                .message("List of guides retrieved successfully")
                .result(guideService.getAllGuides())
                .build();
    }

    @GetMapping("/{guideId}")
    public ApiResponse<Guide> getGuideById(@PathVariable int guideId) {
        return ApiResponse.<Guide>builder()
                .code(1000)
                .message("Guide details retrieved successfully")
                .result(guideService.getGuideById(guideId))
                .build();
    }

    @PutMapping("/{guideId}")
    public ApiResponse<Guide> updateGuide(@PathVariable int guideId, @RequestBody Guide guide) {
        return ApiResponse.<Guide>builder()
                .code(1000)
                .message("Guide updated successfully")
                .result(guideService.updateGuide(guideId, guide))
                .build();
    }

    @DeleteMapping("/{guideId}")
    public ApiResponse<String> deleteGuide(@PathVariable int guideId) {
        guideService.deleteGuide(guideId);
        return ApiResponse.<String>builder()
                .code(1000)
                .message("Guide deleted successfully")
                .result("Guide with ID " + guideId + " has been deleted")
                .build();
    }
}
