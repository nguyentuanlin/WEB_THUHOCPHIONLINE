package org.example.schoolmanagement_api.mapper;

import org.example.schoolmanagement_api.dto.request.StudentCreateRequest;
import org.example.schoolmanagement_api.dto.response.StudentDTO;
import org.example.schoolmanagement_api.entity.Student;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface StudentMapper {

    // Chuyển từ StudentCreateRequest sang Student
    Student toStudent(StudentCreateRequest request);

    // Chuyển từ Student sang StudentDTO
    StudentDTO toStudentDTO(Student student);
}
