package org.example.schoolmanagement_api.controller;

import lombok.RequiredArgsConstructor;
import org.example.schoolmanagement_api.dto.response.ApiResponse;
import org.example.schoolmanagement_api.entity.Invoice;
import org.example.schoolmanagement_api.service.InvoiceService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/invoices")
@RequiredArgsConstructor
public class InvoiceController {

    private final InvoiceService invoiceService;

    // Lấy danh sách hóa đơn chưa thanh toán
    @GetMapping("/unpaid")
    public ApiResponse<List<Invoice>> getUnpaidInvoices() {
        List<Invoice> unpaidInvoices = invoiceService.getInvoicesByStatus(Invoice.InvoiceStatus.UNPAID);
        return ApiResponse.<List<Invoice>>builder()
                .code(1000)
                .message("List of unpaid invoices retrieved successfully")
                .result(unpaidInvoices)
                .build();
    }

    // Lấy danh sách hóa đơn đã thanh toán
    @GetMapping("/paid")
    public ApiResponse<List<Invoice>> getPaidInvoices() {
        List<Invoice> paidInvoices = invoiceService.getInvoicesByStatus(Invoice.InvoiceStatus.PAID);
        return ApiResponse.<List<Invoice>>builder()
                .code(1000)
                .message("List of paid invoices retrieved successfully")
                .result(paidInvoices)
                .build();
    }

    // Lấy danh sách hóa đơn chưa thanh toán cho một sinh viên cụ thể
    @GetMapping("/unpaid/student/{studentId}")
    public ApiResponse<List<Invoice>> getUnpaidInvoicesByStudentId(@PathVariable Integer studentId) {
        List<Invoice> unpaidInvoices = invoiceService.getInvoicesByStudentIdAndStatus(studentId, Invoice.InvoiceStatus.UNPAID);
        return ApiResponse.<List<Invoice>>builder()
                .code(1000)
                .message("List of unpaid invoices for student retrieved successfully")
                .result(unpaidInvoices)
                .build();
    }

    // Lấy danh sách hóa đơn đã thanh toán cho một sinh viên cụ thể
    @GetMapping("/paid/student/{studentId}")
    public ApiResponse<List<Invoice>> getPaidInvoicesByStudentId(@PathVariable Integer studentId) {
        List<Invoice> paidInvoices = invoiceService.getInvoicesByStudentIdAndStatus(studentId, Invoice.InvoiceStatus.PAID);
        return ApiResponse.<List<Invoice>>builder()
                .code(1000)
                .message("List of paid invoices for student retrieved successfully")
                .result(paidInvoices)
                .build();
    }

    // Cập nhật trạng thái của hóa đơn (từ UNPAID sang PAID)
    @PutMapping("/{invoiceId}/pay")
    public ApiResponse<Invoice> payInvoice(@PathVariable Integer invoiceId) {
        Invoice updatedInvoice = invoiceService.updateInvoiceStatus(invoiceId, Invoice.InvoiceStatus.PAID);
        return ApiResponse.<Invoice>builder()
                .code(1000)
                .message("Invoice status updated to PAID successfully")
                .result(updatedInvoice)
                .build();
    }

    // Xóa hóa đơn theo ID
    @DeleteMapping("/{invoiceId}")
    public ApiResponse<String> deleteInvoice(@PathVariable Integer invoiceId) {
        invoiceService.deleteInvoice(invoiceId);
        return ApiResponse.<String>builder()
                .code(1000)
                .message("Invoice deleted successfully")
                .result("Invoice with ID " + invoiceId + " has been deleted")
                .build();
    }
}
