package org.example.schoolmanagement_api.controller;

import jakarta.validation.Valid;
import org.example.schoolmanagement_api.dto.request.UserCreateRequest;
import org.example.schoolmanagement_api.dto.response.ApiResponse;
import org.example.schoolmanagement_api.entity.User;
import org.example.schoolmanagement_api.service.OtpService;
import org.example.schoolmanagement_api.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api_users")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private OtpService otpService;

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @PostMapping("/create")
    ApiResponse<User> createUser(@RequestBody @Valid UserCreateRequest request){
        return ApiResponse.<User>builder()
                .code(1000)
                .message("Call Api create user")
                .result(userService.createUser(request))
                .build();
    }
    // API to delete a user by userId
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @DeleteMapping("/delete/{userId}")
    public ApiResponse<String> deleteUser(@PathVariable int userId) {
        userService.deleteUser(userId);
        return ApiResponse.<String>builder()
                .code(1000)
                .message("User deleted successfully")
                .result("User with ID " + userId + " has been deleted")
                .build();
    }

    // API gửi OTP qua email
    @PostMapping("/password/request_otp")
    public ApiResponse<String> requestOtp(@RequestParam String username) {
        User user = userService.findUserByUsername(username); // Tìm user từ username
        String responseMessage = otpService.sendOtpToUser(user); // Gọi OtpService để gửi OTP
        return ApiResponse.<String>builder()
                .code(1000)
                .message(responseMessage)
                .result("OTP sent successfully")
                .build();
    }

    // API xác thực OTP
    @PostMapping("/password/verify_otp")
    public ApiResponse<String> verifyOtp(
            @RequestParam String username,
            @RequestParam String otpCode) {

        User user = userService.findUserByUsername(username); // Tìm user từ username
        String responseMessage = otpService.verifyOtp(user, otpCode); // Gọi OtpService để xác thực OTP
        return ApiResponse.<String>builder()
                .code(1000)
                .message(responseMessage)
                .result("OTP verified successfully")
                .build();
    }

    // API đổi mật khẩu bằng mật khẩu cũ
    @PostMapping("/password/change_with_old_password")
    public ApiResponse<String> changePasswordWithOldPassword(
            @RequestParam String username,
            @RequestParam String oldPassword,
            @RequestParam String newPassword) {

        String responseMessage = userService.changePasswordWithOldPassword(username, oldPassword, newPassword);
        return ApiResponse.<String>builder()
                .code(1000)
                .message(responseMessage)
                .result("Password changed successfully with old password verification")
                .build();
    }

    // API đổi mật khẩu bằng OTP
    @PostMapping("/password/change_with_otp")
    public ApiResponse<String> changePasswordWithOtp(
            @RequestParam String username,
            @RequestParam String otpCode,
            @RequestParam String newPassword) {

        String responseMessage = userService.changePasswordWithOtp(username, otpCode, newPassword);
        return ApiResponse.<String>builder()
                .code(1000)
                .message(responseMessage)
                .result("Password changed successfully with OTP verification")
                .build();
    }

}
