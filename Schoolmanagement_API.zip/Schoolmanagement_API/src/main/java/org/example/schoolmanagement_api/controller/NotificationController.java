package org.example.schoolmanagement_api.controller;

import lombok.RequiredArgsConstructor;
import org.example.schoolmanagement_api.dto.response.ApiResponse;
import org.example.schoolmanagement_api.entity.Notification;
import org.example.schoolmanagement_api.service.NotificationService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;

    @PostMapping
    public ApiResponse<Notification> createNotification(@RequestBody Notification notification) {
        Notification createdNotification = notificationService.createNotification(notification);
        return ApiResponse.<Notification>builder()
                .code(1000)
                .message("Notification created successfully")
                .result(createdNotification)
                .build();
    }

    @GetMapping
    public ApiResponse<List<Notification>> getAllNotifications() {
        List<Notification> notifications = notificationService.getAllNotifications();
        return ApiResponse.<List<Notification>>builder()
                .code(1000)
                .message("List of notifications retrieved successfully")
                .result(notifications)
                .build();
    }

    @GetMapping("/{notificationId}")
    public ApiResponse<Notification> getNotificationById(@PathVariable int notificationId) {
        Notification notification = notificationService.getNotificationById(notificationId);
        return ApiResponse.<Notification>builder()
                .code(1000)
                .message("Notification details retrieved successfully")
                .result(notification)
                .build();
    }

    @PutMapping("/{notificationId}")
    public ApiResponse<Notification> updateNotification(@PathVariable int notificationId, @RequestBody Notification notification) {
        Notification updatedNotification = notificationService.updateNotification(notificationId, notification);
        return ApiResponse.<Notification>builder()
                .code(1000)
                .message("Notification updated successfully")
                .result(updatedNotification)
                .build();
    }

    @DeleteMapping("/{notificationId}")
    public ApiResponse<String> deleteNotification(@PathVariable int notificationId) {
        notificationService.deleteNotification(notificationId);
        return ApiResponse.<String>builder()
                .code(1000)
                .message("Notification deleted successfully")
                .result("Notification with ID " + notificationId + " has been deleted")
                .build();
    }

    @GetMapping("/role/{role}")
    public ApiResponse<List<Notification>> getNotificationsByRole(@PathVariable String role) {
        List<Notification> notifications = notificationService.getNotificationsByRole(role);
        return ApiResponse.<List<Notification>>builder()
                .code(1000)
                .message("List of notifications retrieved successfully for role: " + role)
                .result(notifications)
                .build();
    }
}
