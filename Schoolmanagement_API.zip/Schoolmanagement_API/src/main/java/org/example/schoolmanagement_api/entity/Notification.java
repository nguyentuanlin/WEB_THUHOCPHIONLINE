package org.example.schoolmanagement_api.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.sql.Timestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "notifications")
@Data
@NoArgsConstructor
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "NotificationID")
    private Integer notificationId;

    @Column(name = "Title")
    private String title;

    @Column(name = "Message")
    private String message;

    @Column(name = "TargetRole")
    private String targetRole; // Ví dụ: "Admin", "Accountant", "Parent"

    @Column(name = "CreatedAt", nullable = false)
    private LocalDateTime createdAt;
}
