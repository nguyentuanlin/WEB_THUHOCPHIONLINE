package org.example.schoolmanagement_api.service;

import lombok.RequiredArgsConstructor;
import org.example.schoolmanagement_api.entity.Invoice;
import org.example.schoolmanagement_api.exception.AppException;
import org.example.schoolmanagement_api.exception.ErrorCode;
import org.example.schoolmanagement_api.repository.InvoiceRepository;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class InvoiceService {

    private final InvoiceRepository invoiceRepository;

    // Lấy danh sách hóa đơn theo trạng thái
    public List<Invoice> getInvoicesByStatus(Invoice.InvoiceStatus status) {
        return invoiceRepository.findByStatus(status);
    }

    // Lấy danh sách hóa đơn theo trạng thái và mã sinh viên
    public List<Invoice> getInvoicesByStudentIdAndStatus(Integer studentId, Invoice.InvoiceStatus status) {
        return invoiceRepository.findByStudent_StudentIdAndStatus(studentId, status);
    }

    // Cập nhật trạng thái của hóa đơn
    public Invoice updateInvoiceStatus(Integer id, Invoice.InvoiceStatus status) {
        Invoice invoice = invoiceRepository.findById(id)
                .orElseThrow(() -> new AppException(ErrorCode.INVOICE_NOT_FOUND));

        // Nếu cập nhật thành trạng thái PAID, lưu ngày thanh toán
        if (status == Invoice.InvoiceStatus.PAID) {
            invoice.setPaidDate(Date.valueOf(LocalDate.now()));
        } else {
            invoice.setPaidDate(null); // Đặt paidDate là null nếu trạng thái không phải là PAID
        }

        invoice.setStatus(status);
        return invoiceRepository.save(invoice);
    }

    // Xóa hóa đơn theo ID
    public void deleteInvoice(Integer id) {
        if (!invoiceRepository.existsById(id)) {
            throw new AppException(ErrorCode.INVOICE_NOT_FOUND);
        }
        invoiceRepository.deleteById(id);
    }
}
