package org.example.schoolmanagement_api.mapper;

import org.example.schoolmanagement_api.dto.request.CreateFeeRateRequest;
import org.example.schoolmanagement_api.dto.response.FeeRateDTO;
import org.example.schoolmanagement_api.entity.FeeRate;
import org.example.schoolmanagement_api.repository.FeeRepository;
import org.example.schoolmanagement_api.repository.FeePeriodRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class FeeRateMapper {

    @Autowired
    private FeeRepository feeRepository;
    @Autowired
    private FeePeriodRepository feePeriodRepository;

    public FeeRateDTO toDTO(FeeRate feeRate) {
        FeeRateDTO dto = new FeeRateDTO();
        dto.setRateId(feeRate.getRateId());
        dto.setAmount(feeRate.getAmount());
        dto.setEffectiveDate(feeRate.getEffectiveDate());
        dto.setFeeId(feeRate.getFee().getFeeId());
        dto.setPeriodId(feeRate.getFeePeriod().getPeriodId());
        return dto;
    }

    public FeeRate toEntity(CreateFeeRateRequest request) {
        var feeRate = new FeeRate();
        feeRate.setAmount(request.getAmount());
        feeRate.setEffectiveDate(request.getEffectiveDate());
        feeRate.setFee(feeRepository.findById(request.getFeeId())
                .orElseThrow(() -> new RuntimeException("Fee not found")));
        feeRate.setFeePeriod(feePeriodRepository.findById(request.getPeriodId())
                .orElseThrow(() -> new RuntimeException("Fee Period not found")));
        return feeRate;
    }

}
