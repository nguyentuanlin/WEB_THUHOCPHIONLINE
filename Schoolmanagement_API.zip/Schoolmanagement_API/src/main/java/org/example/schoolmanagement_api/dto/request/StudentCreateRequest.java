package org.example.schoolmanagement_api.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StudentCreateRequest {

    @NotBlank(message = "Student name is required")
    @Size(max = 255, message = "Student name must not exceed 255 characters")
    private String studentName;

    @NotNull(message = "Date of birth is required")
    private LocalDate dateOfBirth;

    @NotNull(message = "Parent ID is required")
    private Integer parentId;

    @NotBlank(message = "Class is required")
    @Size(max = 50, message = "Class must not exceed 50 characters")
    private String studentClass;

    // Thêm danh sách ID của FeeRate để gán nhiều phí cho sinh viên
    private List<Integer> feeRateIds;
}
