package org.example.schoolmanagement_api.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "students")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "StudentID")
    private Integer studentId;

    @Column(name = "StudentName", nullable = false, length = 255)
    private String studentName;

    @Column(name = "DateOfBirth")
    private LocalDate dateOfBirth;

    @Column(name = "Class", length = 50)
    private String studentClass;

    @Column(name = "CreatedAt", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "LastUpdatedAt")
    private LocalDateTime lastUpdatedAt;

    // Quan hệ nhiều-nhiều với FeeRate
    @ManyToMany
    @JoinTable(
            name = "student_feerate",
            joinColumns = @JoinColumn(name = "StudentID"),
            inverseJoinColumns = @JoinColumn(name = "RateID")
    )
    private List<FeeRate> feeRates;

    // Quan hệ với bảng `User` (đóng vai trò là phụ huynh)
    @ManyToOne
    @JoinColumn(name = "ParentID")
    private User parent;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        lastUpdatedAt = createdAt;
    }

    @PreUpdate
    protected void onUpdate() {
        lastUpdatedAt = LocalDateTime.now();
    }
}
