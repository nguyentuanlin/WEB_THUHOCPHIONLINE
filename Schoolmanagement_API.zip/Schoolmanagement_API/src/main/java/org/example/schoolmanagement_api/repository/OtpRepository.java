    package org.example.schoolmanagement_api.repository;

    import org.example.schoolmanagement_api.entity.Otp;
    import org.example.schoolmanagement_api.entity.User;
    import org.springframework.data.jpa.repository.JpaRepository;

    import java.time.LocalDateTime;
    import java.util.Optional;

    public interface OtpRepository extends JpaRepository<Otp, Long> {
        Optional<Otp> findByOtpCodeAndUserAndIsUsedFalse(String otpCode, User user);

        // Tìm OTP chưa sử dụng và chưa hết hạn cho một người dùng
        Optional<Otp> findByOtpCodeAndUserAndIsUsedFalseAndExpirationTimeAfter(String otpCode, User user, LocalDateTime now);

        // Xóa các OTP đã hết hạn
        void deleteByExpirationTimeBefore(LocalDateTime now);
    }
