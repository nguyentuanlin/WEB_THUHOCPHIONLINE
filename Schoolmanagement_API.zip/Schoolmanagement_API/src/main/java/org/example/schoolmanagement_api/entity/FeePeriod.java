package org.example.schoolmanagement_api.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name = "feeperiods")
@Data
@NoArgsConstructor
public class FeePeriod {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PeriodID")
    private Integer periodId;

    @Column(name = "PeriodName", nullable = false)
    private String periodName;

    @Column(name = "StartDate", nullable = false)
    private Date startDate;

    @Column(name = "EndDate", nullable = false)
    private Date endDate;

    @Column(name = "CreatedAt", nullable = false)
    private Timestamp createdAt;

    @OneToMany(mappedBy = "feePeriod", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore // Ngăn vòng lặp khi tuần tự hóa
    private List<FeeRate> feeRates;
}
