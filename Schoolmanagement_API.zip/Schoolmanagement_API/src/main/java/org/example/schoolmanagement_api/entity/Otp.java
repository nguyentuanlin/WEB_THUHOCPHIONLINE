package org.example.schoolmanagement_api.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "otp")
public class Otp {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String otpCode; // Mã OTP

    @Column(nullable = false)
    private LocalDateTime creationTime; // Thời gian tạo OTP

    @Column(nullable = false)
    private LocalDateTime expirationTime; // Thời gian hết hạn OTP

    @Column(nullable = false)
    private boolean isUsed; // Đánh dấu OTP đã được sử dụng hay chưa

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user; // Tham chiếu đến người dùng liên quan
}
