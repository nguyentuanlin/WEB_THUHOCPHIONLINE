package org.example.schoolmanagement_api.dto.response;

import lombok.Data;
import java.sql.Date;

@Data
public class FeeRateDTO {
    private Integer rateId;
    private double amount;
    private Date effectiveDate;
    private Integer feeId;
    private Integer periodId;
}
