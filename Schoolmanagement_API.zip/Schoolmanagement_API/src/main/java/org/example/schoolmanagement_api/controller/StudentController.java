package org.example.schoolmanagement_api.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.example.schoolmanagement_api.dto.request.StudentCreateRequest;
import org.example.schoolmanagement_api.dto.response.ApiResponse;
import org.example.schoolmanagement_api.dto.response.StudentDTO;
import org.example.schoolmanagement_api.entity.Student;
import org.example.schoolmanagement_api.service.StudentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/students")
@RequiredArgsConstructor
public class StudentController {

    private final StudentService studentService;

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @PostMapping("/create")
    public ApiResponse<Student> createStudent(@RequestBody @Valid StudentCreateRequest request) {
        return ApiResponse.<Student>builder()
                .code(1000)
                .message("Student created successfully")
                .result(studentService.createStudent(request))
                .build();
    }

    @GetMapping("/list")
    public ApiResponse<List<Student>> getAllStudents() {
        return ApiResponse.<List<Student>>builder()
                .code(1000)
                .message("List of students retrieved successfully")
                .result(studentService.getAllStudents())
                .build();
    }

    @GetMapping("/details/{studentId}")
    public ApiResponse<StudentDTO> getStudentById(@PathVariable int studentId) {
        return ApiResponse.<StudentDTO>builder()
                .code(1000)
                .message("Student details retrieved successfully")
                .result(studentService.getStudentById(studentId))
                .build();
    }

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @PutMapping("/update/{studentId}")
    public ApiResponse<StudentDTO> updateStudent(@PathVariable int studentId, @RequestBody @Valid StudentCreateRequest request) {
        return ApiResponse.<StudentDTO>builder()
                .code(1000)
                .message("Student updated successfully")
                .result(studentService.updateStudent(studentId, request))
                .build();
    }

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @DeleteMapping("/delete/{studentId}")
    public ApiResponse<String> deleteStudent(@PathVariable int studentId) {
        studentService.deleteStudent(studentId);
        return ApiResponse.<String>builder()
                .code(1000)
                .message("Student deleted successfully")
                .result("Student with ID " + studentId + " has been deleted")
                .build();
    }

    // API upload file Excel
    @PostMapping("/upload-excel")
    public ResponseEntity<ApiResponse<String>> uploadStudentExcel(@RequestParam("file") MultipartFile file) {
        try {
            List<Student> students = studentService.saveStudentsFromExcel(file);
            return ResponseEntity.ok(ApiResponse.<String>builder()
                    .code(1000)
                    .message("Students created successfully from Excel file.")
                    .result("Total students created: " + students.size())
                    .build());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ApiResponse.<String>builder()
                    .code(500)
                    .message("Failed to create students from Excel file.")
                    .result(e.getMessage())
                    .build());
        }
    }
}
