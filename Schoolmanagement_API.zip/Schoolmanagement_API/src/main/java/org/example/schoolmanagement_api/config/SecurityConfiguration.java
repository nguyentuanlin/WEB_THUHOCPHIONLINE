package org.example.schoolmanagement_api.config;

import org.apache.catalina.filters.CorsFilter;
import org.springframework.core.convert.converter.Converter;
import lombok.experimental.NonFinal;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;


import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration {

    // private final String[] PUBLIC_ENDPOINTS = {"/auth/**","/api/fees/**"};
    private final String[] PUBLIC_ENDPOINTS =  {"/**"};

    @NonFinal
    protected static final String SIGNER_KEY = "7WK94fpjJ9YkxXLLVdgjhOfVyGjG8vQ2JdkmB0zVXEa8B2dvrPFntKF4jushhDvk";


    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())  // Tắt CSRF theo cú pháp mới
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .authorizeHttpRequests(auth -> auth
                    .requestMatchers(HttpMethod.GET, PUBLIC_ENDPOINTS).permitAll()  // Cho phép tất cả các yêu cầu
                    .requestMatchers(HttpMethod.POST, PUBLIC_ENDPOINTS).permitAll()  // Cho phép tất cả các yêu cầu
                    .requestMatchers(HttpMethod.PUT, PUBLIC_ENDPOINTS).permitAll()  // Cho phép tất cả các yêu cầu
                    .requestMatchers(HttpMethod.DELETE, PUBLIC_ENDPOINTS).permitAll() // Cho phép tất cả các yêu cầu
                    .anyRequest().permitAll()  // Mở mọi yêu cầu
            );
        //         .csrf(csrf -> csrf.disable())  // Tắt CSRF theo cú pháp mới
        //         .cors(cors -> cors.configurationSource(corsConfigurationSource()))
        //         .authorizeHttpRequests(auth -> auth
        //                 .requestMatchers(HttpMethod.GET, PUBLIC_ENDPOINTS).permitAll()  // Cho phép tất cả các yêu cầu mà không cần xác thực
        //                 .requestMatchers(HttpMethod.POST, PUBLIC_ENDPOINTS).permitAll()  // Cho phép tất cả các yêu cầu mà không cần xác thực
        //                 .requestMatchers(HttpMethod.PUT, PUBLIC_ENDPOINTS).permitAll()  // Cho phép tất cả các yêu cầu mà không cần xác thực
        //                 .anyRequest().authenticated()
        //         )
        //         .oauth2ResourceServer(oauth2 -> oauth2.jwt(jwt -> jwt.decoder(jwtDecoder())
        //                 .jwtAuthenticationConverter(jwtAuthenticationConverter()))
        //         )
        // ;
        return http.build();
    }
    @Bean
    CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(List.of("http://localhost:3000")); // Chỉ định các nguồn được phép
        configuration.setAllowedMethods(Collections.singletonList("*"));
        configuration.setAllowedHeaders(Collections.singletonList("*"));
        configuration.setAllowCredentials(true);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }

    @Bean
    JwtDecoder  jwtDecoder(){
        SecretKeySpec secretKeySpec = new SecretKeySpec(SIGNER_KEY.getBytes(), "HS512");
        return NimbusJwtDecoder
                .withSecretKey(secretKeySpec)
                .macAlgorithm(MacAlgorithm.HS512)
                .build();
    }
    @Bean
    public Converter<Jwt, AbstractAuthenticationToken> jwtAuthenticationConverter() {
        JwtAuthenticationConverter jwtAuthenticationConverter = new JwtAuthenticationConverter();

        // Sử dụng "role" từ claims làm quyền hạn (authorities) trong Spring Security
        jwtAuthenticationConverter.setJwtGrantedAuthoritiesConverter(jwt -> {
            String role = jwt.getClaimAsString("role");
            return Collections.singletonList(new SimpleGrantedAuthority(role));
        });

        return jwtAuthenticationConverter;
    }
}
