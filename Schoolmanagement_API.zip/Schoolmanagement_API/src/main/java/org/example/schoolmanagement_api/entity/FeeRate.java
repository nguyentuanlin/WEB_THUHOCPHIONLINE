package org.example.schoolmanagement_api.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Builder;
import lombok.Data;
import java.sql.Date;

@Entity
@Table(name = "feerates")
@Data
@Builder
public class FeeRate {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RateID")
    private Integer rateId;

    @Column(name = "Amount", nullable = false)
    private double amount;

    @Column(name = "EffectiveDate", nullable = false)
    private Date effectiveDate;

    @ManyToOne
    @JoinColumn(name = "FeeID", nullable = false)
    private Fee fee;

    @ManyToOne
    @JoinColumn(name = "PeriodID", nullable = false)
    @JsonBackReference // Tránh lặp lại ánh xạ khi truy xuất ngược lại từ FeePeriod
    private FeePeriod feePeriod;
    // Thêm constructor public
    public FeeRate(Integer rateId, double amount, Date effectiveDate, Fee fee, FeePeriod feePeriod) {
        this.rateId = rateId;
        this.amount = amount;
        this.effectiveDate = effectiveDate;
        this.fee = fee;
        this.feePeriod = feePeriod;
    }

    // Constructor không tham số
    public FeeRate() {}
}
