package org.example.schoolmanagement_api.dto.response;

import lombok.Builder;
import lombok.Data;
import org.springframework.web.bind.annotation.ResponseStatus;

@Data
@Builder
public class ApiResponse<T> {
    private int code;
    private String message;
    private T result;

}
