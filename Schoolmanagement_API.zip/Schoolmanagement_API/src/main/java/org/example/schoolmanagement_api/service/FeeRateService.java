package org.example.schoolmanagement_api.service;

import lombok.RequiredArgsConstructor;
import org.example.schoolmanagement_api.dto.request.CreateFeeRateRequest;
import org.example.schoolmanagement_api.entity.FeeRate;
import org.example.schoolmanagement_api.mapper.FeeRateMapper;
import org.example.schoolmanagement_api.repository.FeeRateRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class FeeRateService {

    private final FeeRateRepository feeRateRepository;
    private final FeeRateMapper feeRateMapper;

    public FeeRate createFeeRate(CreateFeeRateRequest request) {
        FeeRate feeRate = feeRateMapper.toEntity(request);
        return feeRateRepository.save(feeRate);
    }

    public List<FeeRate> getAllFeeRates() {
        return feeRateRepository.findAll();
    }

    public FeeRate getFeeRateById(int rateId) {
        return feeRateRepository.findById(rateId)
                .orElseThrow(() -> new RuntimeException("Fee rate not found"));
    }

    public FeeRate updateFeeRate(int rateId, CreateFeeRateRequest request) {
        FeeRate existingFeeRate = getFeeRateById(rateId);
        existingFeeRate.setAmount(request.getAmount());
        existingFeeRate.setEffectiveDate(request.getEffectiveDate());
        existingFeeRate.setFee(feeRateMapper.toEntity(request).getFee());
        existingFeeRate.setFeePeriod(feeRateMapper.toEntity(request).getFeePeriod());
        return feeRateRepository.save(existingFeeRate);
    }

    public void deleteFeeRate(int rateId) {
        if (!feeRateRepository.existsById(rateId)) {
            throw new RuntimeException("Fee rate not found");
        }
        feeRateRepository.deleteById(rateId);
    }
    public List<FeeRate> getAllRatesForFee(int feeId) {
        return feeRateRepository.findAllByFeeFeeId(feeId);
    }
}
