package org.example.schoolmanagement_api.dto.request;

import lombok.Data;
import java.sql.Date;

@Data
public class CreateFeeRateRequest {
    private double amount;
    private Date effectiveDate;
    private int feeId;
    private int periodId;
}
