package org.example.schoolmanagement_api.dto.response;

import lombok.Data;

import java.sql.Timestamp;

@Data
public class AuthenticationLogDTO {
    private Integer logId;
    private Integer userId;
    private Timestamp loginTime;
}
