package org.example.schoolmanagement_api.service;

import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.MACVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.experimental.NonFinal;
import lombok.extern.slf4j.Slf4j;
import org.example.schoolmanagement_api.dto.request.AuthenticationRequest;
import org.example.schoolmanagement_api.dto.request.IntrospectRequest;
import org.example.schoolmanagement_api.dto.response.AuthenticationResponse;
import org.example.schoolmanagement_api.dto.response.IntrospectResponse;
import org.example.schoolmanagement_api.entity.AuthenticationLog;
import org.example.schoolmanagement_api.entity.User;
import org.example.schoolmanagement_api.exception.AppException;
import org.example.schoolmanagement_api.exception.ErrorCode;
import org.example.schoolmanagement_api.repository.AuthenticationLogRepository;
import org.example.schoolmanagement_api.repository.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.text.ParseException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class AuthenticationService {

    UserRepository userRepository;

    @NonFinal
    protected static final String SIGNER_KEY = "7WK94fpjJ9YkxXLLVdgjhOfVyGjG8vQ2JdkmB0zVXEa8B2dvrPFntKF4jushhDvk";
    private final AuthenticationLogRepository authenticationLogRepository;

    public IntrospectResponse introspect(IntrospectRequest request) throws JOSEException, ParseException {

        var token = request.getToken();

        JWSVerifier verifier = new MACVerifier(SIGNER_KEY.getBytes());

        SignedJWT signedJWT = SignedJWT.parse(token);

        Date expiryTime = signedJWT.getJWTClaimsSet().getExpirationTime();

        var verifed = signedJWT.verify(verifier);


        return IntrospectResponse.builder()
                .valid(verifed && expiryTime.after(new Date()))
                .build();

    }

    public AuthenticationResponse authenticate(AuthenticationRequest authenticationRequest) {
        var user = userRepository.findByUsername(authenticationRequest.getUsername())
                .orElseThrow(() -> new AppException(ErrorCode.USER_NOT_EXISTED));
        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder(10);
        boolean authenticated = passwordEncoder.matches(authenticationRequest.getPassword(), user.getPassword());

        if(!authenticated)
            throw new AppException(ErrorCode.AUTHENTICATION_FAILED);

        // Ghi lại thông tin đăng nhập
        log.info("Recording login for user: " + user.getUserId());
        recordLogin(user);

        var token = genarateToken(authenticationRequest.getUsername(), user.getRole());

        return AuthenticationResponse.builder()
                .token(token)
                .authenticated(true)
                .role(user.getRole())
                .build();
    }

    private String genarateToken(String username, String role) {
        JWSHeader header = new JWSHeader(JWSAlgorithm.HS512);

        JWTClaimsSet jwtClaimsSet = new JWTClaimsSet.Builder()
                .subject(username)
                .issuer("schoolmanagement.com")
                .issueTime(new Date())
                .expirationTime(new Date(Instant.now().plus(1, ChronoUnit.DAYS).toEpochMilli()))
                .claim("role",role)
                .build();

        Payload payload = new Payload(jwtClaimsSet.toJSONObject());

        JWSObject JwsObject = new JWSObject(header, payload);

        try {
            JwsObject.sign(new MACSigner(SIGNER_KEY.getBytes()));
            return JwsObject.serialize();
        }catch (JOSEException e) {
            log.error("Cannot create token", e);
            throw new RuntimeException(e);
        }
    }
    private void recordLogin(User user) {
        try {
            AuthenticationLog logAuth = new AuthenticationLog();
            logAuth.setUserId(user.getUserId());
            logAuth.setLoginTime(Timestamp.from(Instant.now())); // Tự động ghi lại thời gian đăng nhập
            authenticationLogRepository.save(logAuth);
            log.info("Login recorded successfully for user: " + user.getUserId() + logAuth.getLoginTime());
        } catch (Exception e) {
            log.error("Failed to record login for user: " + user.getUserId(), e);
        }
    }
}
