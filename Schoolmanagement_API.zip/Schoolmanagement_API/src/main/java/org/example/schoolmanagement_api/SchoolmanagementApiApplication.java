package org.example.schoolmanagement_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolmanagementApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(SchoolmanagementApiApplication.class, args);
    }

}
