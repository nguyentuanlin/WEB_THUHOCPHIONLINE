package org.example.schoolmanagement_api.repository;

import org.example.schoolmanagement_api.entity.Invoice;
import org.example.schoolmanagement_api.entity.Invoice.InvoiceStatus;
import org.example.schoolmanagement_api.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface InvoiceRepository extends JpaRepository<Invoice, Integer> {
    // Tìm hóa đơn dựa trên sinh viên
    List<Invoice> findByStudent(Student student);

    // Tìm hóa đơn theo trạng thái
    List<Invoice> findByStatus(InvoiceStatus status);

    // Tìm hóa đơn chưa thanh toán của một sinh viên cụ thể
    List<Invoice> findByStudentAndStatus(Student student, InvoiceStatus status);

    List<Invoice> findByStudent_StudentIdAndStatus(Integer studentId, InvoiceStatus status);

}
