package org.example.schoolmanagement_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolmanagementApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
